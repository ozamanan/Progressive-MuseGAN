"""Presets of network architectures for model components
"""
